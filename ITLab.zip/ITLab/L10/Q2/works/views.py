from django.shortcuts import render
from .forms import WorksForm
from .models import Works, Lives

def insert_works(request):
    if request.method == 'POST':
        form = WorksForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'insert_works.html', {'success': True})
    else:
        form = WorksForm()
    return render(request, 'insert_works.html', {'form': form, 'success': False})

def retrieve_data(request):
    if request.method == 'POST':
        company_name = request.POST.get('company_name')
        works = Works.objects.filter(company_name=company_name)
        for work in works:
            lives = Lives.objects.filter(person_name=work.person_name)
            work.city = [live.city for live in lives][0]
        return render(request, 'retrieve_data.html', {'works': works})
    return render(request, 'retrieve_data.html')
