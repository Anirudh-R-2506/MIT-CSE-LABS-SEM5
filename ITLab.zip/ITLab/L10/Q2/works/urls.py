from django.urls import path
from . import views

urlpatterns = [
    path('insert_works/', views.insert_works, name='insert_works'),
    path('', views.retrieve_data, name='retrieve_data'),
]
