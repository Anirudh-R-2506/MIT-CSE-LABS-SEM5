from django.shortcuts import render, redirect
from .models import Category, Page
from .forms import PageForm

def add_page(request):
    if request.method == 'POST':
        form = PageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = PageForm()
    return render(request, 'add_page.html', {'form': form})

def index(request):
    categories = Category.objects.all()
    return render(request, 'index.html', {'categories': categories})
