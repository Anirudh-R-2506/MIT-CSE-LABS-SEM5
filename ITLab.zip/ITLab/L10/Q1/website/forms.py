from django import forms
from .models import Category, Page

class PageForm(forms.ModelForm):
    class Meta:
        model = Page
        fields = ['category', 'title', 'url']

    def clean_url(self):
        url = self.cleaned_data['url']
        if not url.startswith('http://') and not url.startswith('https://'):
            raise forms.ValidationError("URL must start with 'http://' or 'https://'.")
        return url
