from django import forms

class InformationForm(forms.Form):
    name = forms.CharField(max_length=100)
    roll = forms.CharField(max_length=100)
    subjects_choices = [
        ('Maths', 'Maths'),
        ('Science', 'Science'),
        ('History', 'History'),
    ]
    subjects = forms.ChoiceField(choices=subjects_choices)