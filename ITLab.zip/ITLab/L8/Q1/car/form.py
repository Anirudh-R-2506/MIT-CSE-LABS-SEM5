from django import forms

class CarForm(forms.Form):
    manufacturer_choices = [
        ('Toyota', 'Toyota'),
        ('Honda', 'Honda'),
        ('Ford', 'Ford'),
    ]
    manufacturer = forms.ChoiceField(choices=manufacturer_choices)
    model_name = forms.CharField(max_length=100)
