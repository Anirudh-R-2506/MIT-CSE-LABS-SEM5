a = float('inf')
m1 = [
    [1, 2, 6],
    [3, 4, 10],
    [2, 5, 19]
]
m2 = [
    [5, 6, 9, 10],
    [7, 8, 12, 56],
    [12, 17, 3, 54],
]
res = []
for i in m1:
    s = []
    for j in zip(*m2):
        s.append(sum(a*b for a,b in zip(i,j)))
    res.append(s)
print(res)