def bsort(l):
    n = len(l)
    for i in range(n-1):
        for j in range(0, n-i-1):
            if l[j] > l[j+1]:
                l[j], l[j+1] = l[j+1], l[j]
    return l

def main():
    print(bsort([1, 4, 2, 8, 3]))
    return

if __name__ == "__main__":
    main()