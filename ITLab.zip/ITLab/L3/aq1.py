l = [45, 32, 29, 90, 78, 100, 240, 2, 34, 44]
s = float('inf')
for i in l:
    s = i if i < s else s
print(f"Smallest no.: {s}")