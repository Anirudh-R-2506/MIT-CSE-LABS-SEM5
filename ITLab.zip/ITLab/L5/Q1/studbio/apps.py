from django.apps import AppConfig


class StudbioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'studbio'
