from django.urls import path
from . import views

urlpatterns = [
    path('', views.book_review, name='book_review'),
]
