from django.shortcuts import render, redirect
from .form import BookReviewForm

def book_review(request):
    if request.method == 'POST':
        form = BookReviewForm(request.POST)
        if form.is_valid():
            review = form.cleaned_data['review']
            request.session[review] = request.session.get(review, 0) + 1
            return redirect('book_review')
    else:
        form = BookReviewForm()
    
    total_votes = sum(request.session.values())
    percentages = {}
    if total_votes > 0:
        percentages = {choice: (request.session.get(choice, 0) / total_votes) * 100 for choice, _ in BookReviewForm.CHOICES}
    return render(request, 'index.html', {'form': form, 'percentages': percentages})
