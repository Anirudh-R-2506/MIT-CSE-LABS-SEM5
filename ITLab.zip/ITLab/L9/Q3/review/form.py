from django import forms

class BookReviewForm(forms.Form):
    CHOICES = (
        ('Good', 'Good'),
        ('Satisfactory', 'Satisfactory'),
        ('Bad', 'Bad'),
    )
    review = forms.ChoiceField(choices=CHOICES, widget=forms.RadioSelect)
