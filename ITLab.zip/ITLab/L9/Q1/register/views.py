from django.shortcuts import render, redirect
from .form import RegisterForm

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            request.session['username'] = form.cleaned_data['username']
            request.session['email'] = form.cleaned_data.get('email', '')
            request.session['contact_number'] = form.cleaned_data.get('contact_number', '')
            return redirect('success')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def success(request):
    username = request.session.get('username')
    email = request.session.get('email')
    contact_number = request.session.get('contact_number')
    return render(request, 'success.html', {'username': username, 'email': email, 'contact_number': contact_number})
