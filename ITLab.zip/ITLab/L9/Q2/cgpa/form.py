from django import forms

class CGPAForm(forms.Form):
    name = forms.CharField(max_length=100)
    total_marks = forms.IntegerField()
