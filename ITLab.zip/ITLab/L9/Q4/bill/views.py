from django.shortcuts import render, redirect
from .form import BillingForm

def first_page(request):
    if request.method == 'POST':
        form = BillingForm(request.POST)
        if form.is_valid():
            request.session['brand'] = form.cleaned_data['brand']
            request.session['items'] = form.cleaned_data['items']
            request.session['quantity'] = form.cleaned_data['quantity']
            return redirect('second_page')
    else:
        form = BillingForm()
    return render(request, 'first_page.html', {'form': form})

def second_page(request):
    brand = request.session.get('brand')
    items = ' '.join(request.session.get('items'))
    quantity = request.session.get('quantity')
    total_amount = calculate_total_amount(brand, items, quantity)
    return render(request, 'second_page.html', {'brand': brand, 'items': items, 'quantity': quantity, 'total_amount': total_amount})

def calculate_total_amount(brand, items, quantity):
    return quantity * 1000
