class Reverser:

    def __init__(self, s) -> None:
        self.s = s

    def rev(self, s) -> str:
        return s[::-1]
    
    def proc(self) -> str:
        return ' '.join([self.rev(a) for a in self.s.split()])
    
print(Reverser('reverse a string word by word').proc())