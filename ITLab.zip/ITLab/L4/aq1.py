class Checker:

    def __init__(self, s) -> None:
        self.s = s

    def validate(self) -> bool:
        return self.__b('()') and self.__b('{}') and self.__b('[]')

    def __b(self, l) -> bool:
        c = 0
        for i in self.s:
            if i == l[0]:
                c += 1
            elif i == l[1]:
                c -= 1
        return c == 0
    
print(Checker("()[]{}").validate())