class Calc:

    def __init__(self, a, b) -> None:
        self.a = a
        self.b = b
    
    def pow(self):
        if self.a == 0 or self.a == 1 or self.b == 1:
            return self.a
        elif self.b == 0:
            return 1
        elif self.b < 0:
            self.b = -self.b
            return self.pow()
        elif self.a == -1:
            return 1 if self.b%2 == 0 else -1
        self.b //= 2
        val = self.pow()
        return val*val if self.b%2 == 0 else val*val*self.a
    
print(f"A^b: {Calc(2,3).pow()}")