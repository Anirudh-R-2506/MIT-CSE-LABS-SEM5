class Subset:

    def __init__(self, l) -> None:
        self.l = l

    def get(self) -> list:
        res = [[]]
        for i in self.l:
            s = [i]
            res.append([i])
            for j in self.l[self.l.index(i)+1:]:
                s.append(j)
                res.append(s[::-1])
        return res

def main():
    l = Subset([1, 4, 2, 8, 3])
    print(l.get())
    return

if __name__ == "__main__":
    main()