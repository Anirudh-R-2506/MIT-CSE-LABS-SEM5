import math

class Circle:

    def __init__(self, r) -> None:
        self.r = r

    def area(self) -> float:
        return math.pi * self.r * self.r
    
    def perimeter(self) -> float:
        return math.pi * self.r * 2
    
c = Circle(5)    
print(f"Area: {c.area()} Perimeter: {c.perimeter()}")