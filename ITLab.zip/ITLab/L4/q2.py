class Calc:

    def __init__(self, l ,t) -> None:
        self.l = l
        self.t = t
    
    def get(self) -> tuple:
        n = len(self.l)
        for i in range(n):
            if i > self.t:
                break
            for j in range(i+1,n):
                if self.l[i]+self.l[j] == self.t:
                    return i,j
        return ()

l = Calc([10,20,30,40,50,60,70,80], 50)
print(l.get())