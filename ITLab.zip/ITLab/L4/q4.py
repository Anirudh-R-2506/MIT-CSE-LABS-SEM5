class Strings:

    s = ''

    def get_string(self) -> None:
        self.s = str(input("Enter string: "))

    def print_string(self) -> None:
        print(self.s.upper())

s = Strings()
s.get_string()
s.print_string()