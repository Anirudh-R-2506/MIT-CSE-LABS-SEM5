#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct pay {
    int arr[4];
    char str[50];
} pay;

void main()
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in ser;
    ser.sin_family = AF_INET;
    ser.sin_addr.s_addr = inet_addr("127.0.0.1");
    ser.sin_port = 8897;
    int c = connect(sock, (struct sockaddr *) &ser, sizeof(ser));
    pay p = { .arr = {4, 6, 2, 9}, .str = "Hey man!"};
    write(sock, &p, sizeof(p));
    int pid;
    read(sock, &p, sizeof(p));
    read(sock, &pid, sizeof(pid));
    for(int i = 0; i<4; i++){
        printf("%d ", p.arr[i]);
    }
    printf("\nChild PID is: %d\n", pid);
}