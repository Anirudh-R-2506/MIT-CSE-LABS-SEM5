#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct pay {
    int arr[4];
    char str[50];
} pay;

void swap(int* xp, int* yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void sort(int arr[], int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

void main()
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in ser, cli;
    int clen, csock;
    ser.sin_family = AF_INET;
    ser.sin_addr.s_addr = INADDR_ANY;
    ser.sin_port = 8897;
    int b = bind(sock, (struct sockaddr *) &ser, sizeof(ser));
    listen(sock, 5);
    while(1){
        csock = accept(sock, (struct sockaddr *) &cli, &clen);
        if (fork() == 0){
            pay p;
            read(csock, &p, sizeof(p));
            sort(p.arr, 4);
            write(csock, &p, sizeof(p));
            int pid = getpid();
            write(csock, &pid, sizeof(pid));
            close(csock);
        }
        else{
            close(csock);
        }
    }
}