#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<string.h>

void main()
{
    int len,result,sockfd,n=1;
    struct sockaddr_in address;
    char ch[256],buf[256];

    sockfd = socket(AF_INET,SOCK_STREAM,0);

    address.sin_family=AF_INET;
    address.sin_port=htons(6996);
    address.sin_addr.s_addr=inet_addr("172.16.48.81");
    len=sizeof(address);

    result=connect(sockfd,(struct sockaddr *)&address,len);

    if(result==-1)
    {
        perror("\nClient Error !!!!\n");
        exit(1);
    }

    while (1){
        printf("\nEnter String ('stop' to quit): \t");
        scanf("%[^\n]s", ch);
        ch[strlen(ch)]='\0'; 

        write(sockfd,ch,strlen(ch));

        if(strcmp(ch,"stop") == 0){
            close(sockfd);
            break;
        }

        read(sockfd,buf,sizeof(buf));
        printf("String after removing duplicates: ");
        printf("%s\n",buf);
    }

}