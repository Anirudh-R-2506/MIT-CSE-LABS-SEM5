#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>

char* removedups(char buf[]){
    char *ss = malloc(strlen(buf) * sizeof(char));
    char *res = malloc(sizeof(char) * strlen(buf));
    int k = 0;
	for(int i = 0; i < strlen(buf); i++){
        if (buf[i] != ' '){
            ss[k] = buf[i];
            k++;
        }
        else{
            if (strstr(res, ss) == NULL){
                strcat(ss, " ");
                strcat(res, ss);
            }
            memset(ss,0,strlen(buf));
            k = 0;
        }
    }
    if (strstr(res, ss) == NULL){
        strcat(ss, " ");
        strcat(res, ss);
    }
    return res;
}

void main()
{
    int sock_id,new_sockid,client_len,n=1;
    struct sockaddr_in server_addr,client_addr;
    int i,value;
    
    sock_id = socket(AF_INET,SOCK_STREAM,0);

    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=inet_addr("172.16.48.81");
    server_addr.sin_port=htons(6996);

    bind(sock_id,(struct sockaddr *)&server_addr,sizeof(server_addr));

    listen(sock_id,5);

    while(1)
    {
        char buf[256]={""};

        printf("\nServer Waiting ...\n");

        client_len=sizeof(client_len);

        new_sockid=accept(sock_id,(struct sockaddr *)&client_addr,&client_len);

        n=read(new_sockid,buf,sizeof(buf));

        if(strcmp(buf,"stop") == 0){
			exit(1);
		}
        char *res = removedups(buf);
        n = write(new_sockid,res,strlen(res));
    } 
}