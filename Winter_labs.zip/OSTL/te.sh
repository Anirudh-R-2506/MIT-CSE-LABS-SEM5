for ((i=0; i<=10; i++)) do
	echo `expr $i + 1`
done
