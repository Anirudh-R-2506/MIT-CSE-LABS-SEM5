#include <stdio.h>

int main(){
	int i;
	printf("Enter: ");
	scanf("%d", &i);
	i++;
	printf("Number is %d\n", i);
	return 0;
}
