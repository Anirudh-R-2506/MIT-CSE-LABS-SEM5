void push();
void pop();
void show();