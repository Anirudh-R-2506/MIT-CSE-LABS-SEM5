mkdir /home/test && mkdir /home/test/sub1 && mkdir /home/test/sub2

touch /home/test/sub1/f1.txt && echo "test_content_1" > /home/test/sub1/f1.txt
touch /home/test/sub1/f2.txt && echo "test_content_2" > /home/test/sub1/f2.txt
touch /home/test/sub1/f3.txt && echo "test_content_3" > /home/test/sub1/f3.txt

cp /home/test/sub1/f1.txt /home/test/sub2/f1.txt

touch /home/test/sub2/f2.txt && who | wc -l > /home/test/sub2/f2.txt && ls /home/test/sub2 | wc -l >> /home/test/sub2/f2.txt

ls | grep -E "a|A"

ls -l | grep "^-" | wc -l

cc test.c && echo "success"

cat q.sh | wc -l