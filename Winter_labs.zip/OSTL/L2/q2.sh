if [ $# != 2 ]; then
    echo "Usage: $0 <directory> <regular expression>"
    exit 1
fi

ls $1 | grep -E "$2"