echo "Enter path to directory"
read dirname
find "$dirname" -type f -name '*.?'