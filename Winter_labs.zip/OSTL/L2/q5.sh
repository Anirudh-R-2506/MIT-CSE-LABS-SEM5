if [ $# != 2 ]; then
    echo "Usage: $0 <file> <file>"
    exit 1
fi

if [ ! -f "$1" ] || [ ! -f "$2" ]; then
    echo "Error: Input files do not exist."
    exit 1
fi

sort -n "$1" "$2" | uniq > merged.txt