if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <file_format> <destination_directory>"
    exit 1
fi

if [ ! -d "$2" ]; then
    mkdir -p "$2"
fi

cp *."$1" "$2"