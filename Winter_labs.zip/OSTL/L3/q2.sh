echo "Enter a number "
read n
for ((i=1; i<n; i=i+2)) do
	echo $i;
done