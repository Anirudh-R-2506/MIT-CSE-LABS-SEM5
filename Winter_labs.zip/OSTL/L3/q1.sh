echo "Enter a number"
read number
rem=`expr $number % 2`
[ $rem -eq 0 ] && echo "The number entered is even" || echo "The number entered is odd"